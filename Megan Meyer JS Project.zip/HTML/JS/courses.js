var course = ["intro", "beginner", "intermediate", "social", "career",]


var intro = [
  {
    title : 'Web Pages',
    description : 'Code a simple one-page website using HTML and JQuery',
    duration : '3 hours',
    cost : 'R250',
  },
  {
    title : 'Music',
    description : 'Code a song using SonicPi software on a Raspberry Pi computer.',
    duration : '3 hours',
    cost : 'R250',
  },
  {
    title : 'Web Pages',
    description : 'Create a 2D animation using coding language JavaScript.',
    duration : '3 hours',
    cost : 'R250',
  },
  {
    title : 'Web Pages',
    description : 'Learn how the internet works and code a simple one-page website using HTML, CSS and JQuery.',
    duration : '3 Days',
    cost : 'R960',
  },
  {
    title : 'Music',
    description : 'Learn computer science principles by coding music with a Raspberry Pi computer.',
    duration : '3 Days',
    cost : 'R960',
  },
  {
    title : 'Animation',
    description : 'Learn computer science principles by coding animations using JavaScript.',
    duration : '3 Days',
    cost : 'R960',
  },
  {
    title : 'Developer',
    description : 'Learn how to set up a development environment and practical skills to start coding.',
    duration : '3 hours',
    cost : 'R250',
  }
];

var beginner = [
  {
    title : 'JavaScript',
    description : 'Develop a basic proficiency in programming structures and methods in JavaScript so that you are able to create an interactive web application.',
    duration : '6 Days',
    cost : 'R1800',
  },
  {
    title : 'Front End Web Development',
    description : 'Develop a good proficiency in CSS and an understanding of web design principles so that you are able to create visually pleasing web pages.',
    duration : '6 Days',
    cost : 'R1800',
  },
  {
    title : 'Python',
    description : 'Develop a basic proficiency in programming principles and methods in Python.',
    duration : '6 Days',
    cost : 'R1800',
  }
];

var intermediate = [
  {
    title : 'Full Stack JavaScript',
    description : 'Develop an understanding of the front and backend development environment and basic proficiency in server side JavaScript and object-oriented programming. By the end of the course you will be able to architect an application, control flow in an application and persist and retrieve data in a database.',
    duration :' 6 Days',
    cost : 'R1800',
  },
  {
    title : 'Website Deployment',
    description : 'Learn how to manage and deploy code to a server environment so that you can host your own web pages.',
    duration : '4 Days',
    cost : 'R1200',
  }
];

var social = [
  {
    title : 'Innovation Challenge',
    description :' Develop an understanding of the front and backend development environment and basic proficiency in server side JavaScript and object-oriented programming. By the end of the course you will be able to architect an application, control flow in an application and persist and retrieve data in a database.',
    duration : '6 Days',
    cost : 'R1800',
  },
  {
    title : 'CodeStorm',
    description : 'Work in groups to create and present a code project that addresses a particular issue.',
    duration : '5 Days',
    cost : 'R1500',
  },
  {
    title : 'Hackathon',
    description : 'Learn how to manage and deploy code to a server environment so that you can host your own web pages.',
    duration : 'TBC',
    cost : 'TBC',
  },
  {
    title : 'Industry Immersion',
    description :' Spend a week at a tech company and gain experience in industry.',
    duration :' 5 Days',
    cost :' R1500',
  }
];

var career = [
  {
    title : 'Code Conversation',
    description : 'Learn about tech careers from a panel of working professionals who will share their experiences with you.',
    duration : '1 Day',
    cost : 'R300',
  },
  {
    title : 'Presentation Skills',
    description : 'Learn how to present an idea or project in a compelling manner.',
    duration : '1 Day',
    cost : 'R300',
  },
  {
    title : 'CV & LinkedIn',
    description : 'Learn how to present your skills effectively. ',
    duration : '1 Day',
    cost : 'R300',
  },
  {
    title : 'Networking',
    description : 'Learn how to present yourself professionally when networking and put your skills to the test by attending local tech events. You will attend a training session and attend one event of your choice.',
    duration : '2 Day',
    cost : 'R300',
  },
  {
    title : 'Digital Communication Skills',
    description : 'Learn how to communicate and collaborate in a 21st century work environment using digital workplace tools. ',
    duration : '1 Day',
    cost : 'R300',
  },
  {
    title : 'Applying to Tertiary Studies',
    description : 'Make informed decisions about your future studies. ',
    duration : '1 Day',
    cost : 'R300',
  }
];


function print(message) {
  const OACDiv = document.getElementById(['intoWebPages', 'create'] );
  OACDiv.innerHTML= message;
}

function getintroReport(intro){
  let report = '<h4><ins> Focus: &nbsp;' + intro.title + '</ins></h4></br>';
  report +=  '<p><ins>Goal:</ins>  &nbsp;' + intro.description + '</p>';
  report +=  '<p><ins>Time:</ins> &nbsp;' + intro.duration  +'</p>';
  report +=  '<p><ins>Cost:</ins> &nbsp;' + intro.cost + '</p>',
  report +=  '<p><button id="join"> Sign Up </button></p>'

  return report;
}

//console.log(introCodingCourses);

$("#WebDisplay1").click(function (){
	$("#IntroWebPages").show();
	message = getintroReport(intro[0]);
	print(message);
	});

$("#WebDisplay2").click(function (){
	$("#create").show();
	message = getintroReport(intro[2]);
	print(message);
	});


$("#WebDisplay3").click(function (){
	$("#createWeb").show();
	message = getintroReport(intro[3]);
	print(message);
	});

$("#MusicDisplay1").click(function (){
	$("#intoMusic").show();
	message = getintroReport(intro[1]);
	print(message);
	});

$("#MusicDisplay2").click(function (){
	$("#createMusic").show();
	message = getintroReport(intro[4]);
	print(message);
	});


$("#MoreDisplay1").click(function (){
	$("#anime").show();
	message = getintroReport(intro[5]);
	print(message);
	});

$("#MoreDisplay2").click(function (){
	$("#dev").show();
	message = getintroReport(intro[6]);
	print(message);
	});

function getbeginnerReport(beginner){
  let report = '<h4><ins> Focus: &nbsp;' + beginner.title + '</ins></h4></br>';
  report +=  '<p><ins>Goal:</ins>  &nbsp;' + beginner.description + '</p>';
  report +=  '<p><ins>Time:</ins> &nbsp;' + beginner.duration  +'</p>';
  report +=  '<p><ins>Cost:</ins> &nbsp;' + beginner.cost + '</p>',
  report +=  '<p><button id="join"> Sign Up </button></p>'

  return report;
}

$("#beginnerDisplay1").click(function (){
	$("#js").show();
	message = getbeginnerReport(beginner[0]);
	print(message);
	});

$("#beginnerDisplay2").click(function (){
	$("#front-end").show();
	message = getbeginnerReport(beginner[1]);
	print(message);
	});


$("#beginnerDisplay3").click(function (){
	$("#python").show();
	message = getbeginnerReport(beginner[2]);
	print(message);
	});

function getintermediateReport(intermediate){
  let report = '<h4><ins> Focus: &nbsp;' + intermediate.title + '</ins></h4></br>';
  report +=  '<p><ins>Goal:</ins>  &nbsp;' + intermediate.description + '</p>';
  report +=  '<p><ins>Time:</ins> &nbsp;' + intermediate.duration  +'</p>';
  report +=  '<p><ins>Cost:</ins> &nbsp;' + intermediate.cost + '</p>',
  report +=  '<p><button id="join"> Sign Up </button></p>'

  return report;
}

$("#intermediateDisplay1").click(function (){
	$("#FulSt").show();
	message = getintermediateReport(intermediate[0]);
	print(message);
	});

$("#intermediateDisplay2").click(function (){
	$("#Web-Dep").show();
	message = getintermediateReport(intermediate[1]);
	print(message);
	});

function getsocialReport(social){
  let report = '<h4><ins> Focus: &nbsp;' + social.title + '</ins></h4></br>';
  report +=  '<p><ins>Goal:</ins>  &nbsp;' + social.description + '</p>';
  report +=  '<p><ins>Time:</ins> &nbsp;' + social.duration  +'</p>';
  report +=  '<p><ins>Cost:</ins> &nbsp;' + social.cost + '</p>',
  report +=  '<p><button id="join"> Sign Up </button></p>'

  return report;
}

$("#socialDisplay1").click(function (){
	$("#Inno").show();
	message = getsocialReport(social[0]);
	print(message);
	});

$("#socialDisplay2").click(function (){
	$("#Storm").show();
	message = getsocialReport(social[1]);
	print(message);
	});

$("#socialDisplay3").click(function (){
	$("#Hack").show();
	message = getsocialReport(social[2]);
	print(message);
	});

$("#socialDisplay4").click(function (){
	$("#Ind").show();
	message = getsocialReport(social[3]);
	print(message);
	});

function getcareerReport(career){
  let report = '<h4><ins> Focus: &nbsp;' + career.title + '</ins></h4></br>';
  report +=  '<p><ins>Goal:</ins>  &nbsp;' + career.description + '</p>';
  report +=  '<p><ins>Time:</ins> &nbsp;' + career.duration  +'</p>';
  report +=  '<p><ins>Cost:</ins> &nbsp;' + career.cost + '</p>',
  report +=  '<p><button id="join"> Sign Up </button></p>'

  return report;
}

$("#socialDisplay1").click(function (){
	$("#FulSt").show();
	message = getcareerReport(career[0]);
	print(message);
	});

$("#socialDisplay2").click(function (){
	$("#Web-Dep").show();
	message = getcareerReport(career[1]);
	print(message);
	});

$("#socialDisplay3").click(function (){
	$("#FulSt").show();
	message = getcareerReport(career[2]);
	print(message);
	});

$("#socialDisplay4").click(function (){
	$("#Web-Dep").show();
	message = getcareerReport(career[3]);
	print(message);
	});

$("#socialDispla5").click(function (){
	$("#Web-Dep").show();
	message = getcareerReport(career[4]);
	print(message);
	});

$("#socialDisplay6").click(function (){
	$("#Web-Dep").show();
	message = getcareerReport(career[5]);
	print(message);
	});
